# ✅ Cloudflare Pages Upload Checklist

## Before Creating Your Zip File

### ❌ EXCLUDE These (Don't Include in Zip):

1. **`backend-csharp/`** - C# backend folder (not needed for Pages)
2. **`backend/`** - Python backend folder (removed)
3. **`node_modules/`** - If present
4. **`.git/`** - Git folder (if present)
5. **`wrangler.toml`** - Already removed ✅
6. **`cloudflare-pages.json`** - Removed (was causing build error) ✅
7. **Any `.env` files** - Environment variables
8. **`*.bat` files** - Windows batch files (optional, but not needed)
9. **`*.md` files** - Documentation files (optional, but not needed for site)

### ✅ INCLUDE These (Must Be in Zip):

1. **`index.html`** - Main page
2. **`styles.css`** - Styles
3. **`script.js`** - JavaScript
4. **`payment.html`** - Payment page
5. **`success.html`** - Success page
6. **`cancel.html`** - Cancel page
7. **`admin.html`** - Admin page (if needed)
8. **`web/`** - Entire web folder with all platform pages
9. **`functions/`** - **CRITICAL!** Cloudflare Pages Functions (API)
10. **`_redirects`** - **CRITICAL!** SPA routing
11. **`images/`** - All images
12. **`fonts/`** - All fonts
13. **`js/`** - JavaScript libraries
14. **`css/`** - Additional CSS files

## Quick Zip Creation (Windows PowerShell)

```powershell
# Navigate to website folder
cd C:\Users\Admin\Desktop\website

# Create zip excluding backend folders
Compress-Archive -Path index.html,styles.css,script.js,payment.html,success.html,cancel.html,admin.html,web,functions,_redirects,images,fonts,js,css -DestinationPath crymson-site.zip -Force
```

Or manually:
1. Select all files EXCEPT `backend-csharp` and `backend`
2. Right-click → Send to → Compressed (zipped) folder
3. Name it `crymson-site.zip`

## Verify Your Zip Contains:

- ✅ `functions/api/` folder with `.js` files
- ✅ `_redirects` file in root
- ✅ `web/` folder
- ✅ All HTML files
- ❌ NO `backend-csharp/` folder
- ❌ NO `backend/` folder
- ❌ NO `wrangler.toml`
- ❌ NO `cloudflare-pages.json`

## Upload Steps

1. Go to [Cloudflare Dashboard](https://dash.cloudflare.com/)
2. **Pages** → **Create a project**
3. **Upload assets**
4. Drag and drop your zip file
5. Wait for deployment
6. Done! 🎉

## If You Still Get Build Error

The error might be cached. Try:
1. Create a **fresh zip** with only the required files
2. Make sure `cloudflare-pages.json` is NOT in the zip
3. Make sure `wrangler.toml` is NOT in the zip
4. Make sure no `backend-*` folders are in the zip

