# Quick Upload Instructions for Cloudflare Pages

## ⚠️ Important: Before Uploading

**Exclude these from your zip file:**
- ❌ `backend-csharp/` folder (C# backend - not needed for Pages)
- ❌ `backend/` folder (Python backend - already removed)
- ❌ `node_modules/` folder (if present)
- ❌ `wrangler.toml` (for Workers, not Pages - already removed)
- ❌ `cloudflare-pages.json` (was causing build error - already removed)
- ❌ `.git/` folder (if present)
- ❌ Any `.env` files

## ✅ What to Include

- ✅ All HTML files (`index.html`, `payment.html`, etc.)
- ✅ All CSS/JS files
- ✅ `web/` folder (all platform pages)
- ✅ `images/`, `fonts/`, `js/`, `css/` folders
- ✅ `functions/` folder (API endpoints) - **IMPORTANT!**
- ✅ `_redirects` file - **IMPORTANT!**

## Step-by-Step Upload

1. **Create a clean folder** with only the files you need
2. **Zip the folder** (make sure `functions/` and `_redirects` are included)
3. Go to [Cloudflare Dashboard](https://dash.cloudflare.com/)
4. Navigate to **Pages** → **Create a project**
5. Select **Upload assets**
6. Upload your zip file
7. Wait for deployment (usually 30-60 seconds)
8. Your site is live! 🎉

## Verify After Upload

1. Check that your site loads: `https://your-project.pages.dev`
2. Test API endpoints: `https://your-project.pages.dev/api/stats`
3. Check that `functions/` are working (they should work automatically)

## Troubleshooting

### "Uploader does not support build process" Error
- ✅ **Fixed!** `wrangler.toml` has been removed
- ✅ **Fixed!** `cloudflare-pages.json` has been removed (was causing the error)
- Make sure you're not including `backend-csharp/` folder
- Make sure you're not including any build config files
- Create a **fresh zip** file with only the required files

### API Endpoints Not Working
- Verify `functions/` folder is in your zip
- Check that files are in `functions/api/` structure
- Functions should work automatically - no build needed

### 404 Errors on Routes
- Make sure `_redirects` file is in the root of your zip
- Content should be: `/* /index.html 200`

## Alternative: Git Integration (No Upload Needed)

If you keep getting upload errors, use Git integration instead:

1. Push your code to GitHub
2. Connect GitHub to Cloudflare Pages
3. Cloudflare will auto-deploy on every push
4. No zip file needed!

