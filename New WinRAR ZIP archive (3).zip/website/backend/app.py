from flask import Flask, render_template, jsonify, request, send_from_directory, redirect, Response
from flask_cors import CORS
from flask_compress import Compress
from functools import wraps, lru_cache
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
import random
import json
import os
import threading
import time
from datetime import datetime, timedelta
from collections import defaultdict
import hashlib

app = Flask(__name__, static_folder='../', static_url_path='')
CORS(app, resources={r"/api/*": {"origins": "*"}})

# Enable gzip compression for faster responses
Compress(app)

# ========================================
# SECURITY & PERFORMANCE CONFIGURATION
# ========================================
app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 31536000  # 1 year cache for static files
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max upload

# Security headers
@app.after_request
def set_security_headers(response):
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'DENY'
    response.headers['X-XSS-Protection'] = '1; mode=block'
    response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
    response.headers['Permissions-Policy'] = 'geolocation=(), microphone=(), camera=()'
    return response

# Rate limiting (simple in-memory)
rate_limit_store = defaultdict(list)
RATE_LIMIT_REQUESTS = 100
RATE_LIMIT_WINDOW = 60  # seconds

def rate_limit(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        ip = request.remote_addr
        now = time.time()
        
        # Clean old entries
        rate_limit_store[ip] = [req_time for req_time in rate_limit_store[ip] if now - req_time < RATE_LIMIT_WINDOW]
        
        # Check limit
        if len(rate_limit_store[ip]) >= RATE_LIMIT_REQUESTS:
            return jsonify({'error': 'Rate limit exceeded'}), 429
        
        # Add current request
        rate_limit_store[ip].append(now)
        return f(*args, **kwargs)
    return decorated_function

# ========================================
# OPTIMIZED HTTP SESSION WITH POOLING
# ========================================
session = requests.Session()
retry_strategy = Retry(
    total=3,
    backoff_factor=1,
    status_forcelist=[429, 500, 502, 503, 504],
)
adapter = HTTPAdapter(max_retries=retry_strategy, pool_connections=10, pool_maxsize=20)
session.mount("http://", adapter)
session.mount("https://", adapter)
session.headers.update({
    'User-Agent': 'Crymson/1.0',
    'Accept': 'application/json',
    'Accept-Encoding': 'gzip, deflate'
})

# ========================================
# CONFIGURATION
# ========================================
STEAM_API_URL = "https://store.steampowered.com/api"
STEAM_STOREFRONT_URL = "https://store.steampowered.com/api/featuredcategories"
STEAM_FEATURED_URL = "https://store.steampowered.com/api/featured"

# Stripe Configuration
STRIPE_CHECKOUT_URL = "https://buy.stripe.com/14A00kdlSdny7ZL14qaR203"
CRYMSON_PRICE = 13.00
PURCHASES_FILE = 'purchases.json'

# Enhanced cache with thread safety
cache_lock = threading.Lock()
games_cache = {
    'data': [],
    'timestamp': None,
    'ttl': 600,  # 10 minutes
    'hash': None
}

# ========================================
# PURCHASE TRACKING (Thread-safe)
# ========================================
purchase_lock = threading.Lock()

def load_purchases():
    """Load purchases from file (thread-safe)"""
    if not os.path.exists(PURCHASES_FILE):
        return []
    
    try:
        with purchase_lock:
            with open(PURCHASES_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
    except (json.JSONDecodeError, IOError) as e:
        print(f"Error loading purchases: {e}")
        return []

def save_purchase(purchase_data):
    """Save purchase (thread-safe)"""
    try:
        with purchase_lock:
            purchases = load_purchases()
            purchases.append(purchase_data)
            with open(PURCHASES_FILE, 'w', encoding='utf-8') as f:
                json.dump(purchases, f, indent=2, ensure_ascii=False)
        print(f"💰 NEW PURCHASE: {purchase_data.get('customer_email', 'N/A')}")
    except Exception as e:
        print(f"Error saving purchase: {e}")

def get_total_purchases():
    """Get total purchases count"""
    return len(load_purchases())

# ========================================
# STATIC FILE ROUTES (Optimized)
# ========================================
@app.route('/')
def index():
    response = app.send_static_file('index.html')
    response.headers['Cache-Control'] = 'public, max-age=3600'
    return response

@app.route('/success')
def success_page():
    response = app.send_static_file('success.html')
    response.headers['Cache-Control'] = 'public, max-age=3600'
    return response

@app.route('/cancel')
def cancel_page():
    response = app.send_static_file('cancel.html')
    response.headers['Cache-Control'] = 'public, max-age=3600'
    return response

@app.route('/admin')
def admin_page():
    response = app.send_static_file('admin.html')
    response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
    return response

@app.route('/preview')
def preview_page():
    response = app.send_static_file('preview.html')
    response.headers['Cache-Control'] = 'public, max-age=3600'
    return response

@app.route('/payment')
def payment_page():
    response = app.send_static_file('payment.html')
    response.headers['Cache-Control'] = 'public, max-age=3600'
    return response

@app.route('/web/')
@app.route('/web/<path:filename>')
def serve_web_folder(filename='index.html'):
    web_path = os.path.join(app.static_folder, 'web')
    response = send_from_directory(web_path, filename)
    response.headers['Cache-Control'] = 'public, max-age=86400'  # 1 day
    return response

@app.route('/<path:path>')
def serve_static(path):
    if path.endswith(('.css', '.js', '.html', '.ico', '.png', '.jpg', '.svg', '.woff', '.woff2')):
        response = app.send_static_file(path)
        # Long cache for static assets
        if path.endswith(('.css', '.js', '.woff', '.woff2')):
            response.headers['Cache-Control'] = 'public, max-age=31536000'  # 1 year
        return response
    return app.send_static_file('index.html')

# ========================================
# STRIPE CHECKOUT
# ========================================
@app.route('/api/checkout')
@rate_limit
def checkout():
    return jsonify({
        'checkout_url': STRIPE_CHECKOUT_URL,
        'price': CRYMSON_PRICE
    })

@app.route('/checkout')
def checkout_redirect():
    return redirect(STRIPE_CHECKOUT_URL)

# ========================================
# STEAM API INTEGRATION (Optimized)
# ========================================
def fetch_steam_featured_games():
    """Fetch featured games with timeout and error handling"""
    try:
        response = session.get(STEAM_FEATURED_URL, timeout=5)
        response.raise_for_status()
        data = response.json()
        games = []
        
        for platform in ['featured_win', 'featured_mac', 'featured_linux']:
            if platform in data:
                for game in data[platform]:
                    games.append({
                        'id': game.get('id'),
                        'name': game.get('name', 'Unknown'),
                        'image': game.get('header_image', game.get('large_capsule_image', '')),
                        'available': True
                    })
        
        return games
    except (requests.RequestException, KeyError, ValueError) as e:
        print(f"Error fetching Steam featured: {e}")
        return []

def fetch_steam_categories():
    """Fetch categories with timeout"""
    try:
        response = session.get(STEAM_STOREFRONT_URL, timeout=5)
        response.raise_for_status()
        data = response.json()
        games = []
        
        for category in ['specials', 'top_sellers', 'new_releases', 'coming_soon']:
            if category in data and 'items' in data[category]:
                for game in data[category]['items']:
                    games.append({
                        'id': game.get('id'),
                        'name': game.get('name', 'Unknown'),
                        'image': game.get('header_image', game.get('large_capsule_image', '')),
                        'available': True
                    })
        
        return games
    except (requests.RequestException, KeyError, ValueError) as e:
        print(f"Error fetching Steam categories: {e}")
        return []

def get_cache_hash(data):
    """Generate hash for cache validation"""
    return hashlib.md5(json.dumps(data, sort_keys=True).encode()).hexdigest()

@lru_cache(maxsize=1)
def get_all_games_cached():
    """Cached version - called internally"""
    featured = fetch_steam_featured_games()
    categories = fetch_steam_categories()
    
    all_games = featured + categories
    
    seen_ids = set()
    unique_games = []
    for game in all_games:
        if game.get('id') and game['id'] not in seen_ids:
            seen_ids.add(game['id'])
            unique_games.append(game)
    
    if len(unique_games) < 160:
        unique_games.extend(FALLBACK_GAMES[:160 - len(unique_games)])
    
    for i, game in enumerate(unique_games[:160]):
        game['number'] = i + 1
    
    return unique_games[:160]

def get_all_games():
    """Get all games with thread-safe caching"""
    now = datetime.now()
    
    with cache_lock:
        if games_cache['data'] and games_cache['timestamp']:
            elapsed = (now - games_cache['timestamp']).total_seconds()
            if elapsed < games_cache['ttl']:
                return games_cache['data']
        
        # Fetch new data
        games = get_all_games_cached()
        cache_hash = get_cache_hash(games)
        
        games_cache['data'] = games
        games_cache['timestamp'] = now
        games_cache['hash'] = cache_hash
        
        # Clear LRU cache periodically
        if random.random() < 0.1:  # 10% chance
            get_all_games_cached.cache_clear()
    
    return games

# Fallback games (pre-loaded)
FALLBACK_GAMES = [
    {'id': i, 'name': name, 'image': '', 'available': True}
    for i, name in enumerate([
        'Cyberpunk 2077', 'ELDEN RING', 'Red Dead Redemption 2', 'Grand Theft Auto V',
        'Hollow Knight', 'Stardew Valley', 'Fortnite', 'Valorant', 'Counter-Strike 2',
        'Dota 2', 'Baldur\'s Gate 3', 'God of War', 'The Witcher 3', 'Minecraft',
        'Terraria', 'Among Us', 'Fall Guys', 'Apex Legends', 'League of Legends',
        'Overwatch 2', 'Destiny 2', 'Warframe', 'Path of Exile', 'Lost Ark',
        'Diablo IV', 'Hogwarts Legacy', 'Starfield', 'Spider-Man Remastered',
        'Horizon Zero Dawn', 'Death Stranding', 'Hades', 'Celeste', 'Cuphead',
        'Sekiro', 'Dark Souls III', 'Monster Hunter World', 'Resident Evil 4',
        'RE Village', 'Silent Hill 2', 'Dead Space', 'Alan Wake 2', 'Lies of P',
        'Armored Core VI', 'Street Fighter 6', 'Mortal Kombat 1', 'Tekken 8',
        'FIFA 24', 'NBA 2K24', 'Forza Horizon 5', 'Gran Turismo 7', 'Rocket League',
        'Euro Truck Simulator 2', 'Microsoft Flight Simulator', 'Cities Skylines II',
        'RimWorld', 'Factorio', 'Satisfactory', 'Subnautica', 'No Man\'s Sky',
        'Sea of Thieves', 'Rust', 'ARK Survival Evolved', 'Valheim', 'V Rising',
        'Phasmophobia', 'Lethal Company', 'Palworld', 'Sons of the Forest',
        'Project Zomboid', 'DayZ', 'PUBG', 'Escape from Tarkov', 'Hunt Showdown',
        'Ready or Not', 'Rainbow Six Siege', 'Call of Duty MW3', 'Halo Infinite',
        'Doom Eternal', 'Titanfall 2', 'Borderlands 3', 'Far Cry 6',
        'Assassin\'s Creed Mirage', 'Ghost Recon Breakpoint', 'The Division 2',
        'Remnant 2', 'Deep Rock Galactic', 'Risk of Rain 2', 'Vampire Survivors',
        'Cult of the Lamb', 'Dead Cells', 'Slay the Spire', 'Disco Elysium',
        'Divinity Original Sin 2', 'XCOM 2', 'Darkest Dungeon', 'Crusader Kings III',
        'Europa Universalis IV', 'Hearts of Iron IV', 'Stellaris', 'Civilization VI',
        'Age of Empires IV', 'Total War Warhammer III', 'Starcraft II', 'Anno 1800',
        'Frostpunk', 'Dyson Sphere Program', 'Oxygen Not Included', 'Don\'t Starve',
        'Raft', 'The Long Dark', 'Grounded', 'Astroneer', 'Outer Wilds',
        'Portal 2', 'Half-Life Alyx', 'Beat Saber', 'VRChat', 'Blade and Sorcery',
        'The Last of Us Part I', 'Ghost of Tsushima', 'God of War Ragnarok',
        'Ratchet & Clank', 'Returnal', 'Uncharted 4', 'Horizon Forbidden West',
        'Final Fantasy XVI', 'Final Fantasy VII Remake', 'Persona 5', 'Nier Automata',
        'Kingdom Hearts III', 'Tales of Arise', 'Xenoblade Chronicles 3',
        'Fire Emblem Three Houses', 'Pokemon Legends Arceus', 'Monster Hunter Rise',
        'Dragon Quest XI', 'Octopath Traveler', 'Bravely Default II',
        'Triangle Strategy', 'Live A Live', 'Chrono Cross', 'Vagrant Story',
        'Final Fantasy IX', 'Final Fantasy X', 'Kingdom Come Deliverance',
        'Mount & Blade II', 'Kenshi', 'Dwarf Fortress', 'Caves of Qud',
        'Noita', 'Spelunky 2', 'Enter the Gungeon', 'Nuclear Throne', 'Hotline Miami',
        'Katana ZERO', 'Hyper Light Drifter', 'Furi', 'Sifu', 'Absolver',
        'For Honor', 'Chivalry 2', 'Mordhau', 'War Thunder', 'World of Tanks'
    ], start=1)
]

# ========================================
# API ROUTES (Optimized with caching)
# ========================================
@app.route('/api/games')
@rate_limit
def get_games():
    """Get paginated games"""
    try:
        page = max(1, int(request.args.get('page', 1)))
        limit = max(1, min(50, int(request.args.get('limit', 8))))
    except (ValueError, TypeError):
        page, limit = 1, 8
    
    games = get_all_games()
    
    start = (page - 1) * limit
    end = start + limit
    paginated_games = games[start:end]
    
    response = jsonify({
        'games': paginated_games,
        'total': len(games),
        'page': page,
        'shown': min(end, len(games)),
        'has_more': end < len(games)
    })
    response.headers['Cache-Control'] = 'public, max-age=300'  # 5 minutes
    return response

@app.route('/api/stats')
@rate_limit
def get_stats():
    """Get platform statistics"""
    response = jsonify({
        'total_games': 'Infinite',
        'total_players': 2300,
        'online_now': random.randint(200, 400),
        'price': CRYMSON_PRICE,
        'countries': 150
    })
    response.headers['Cache-Control'] = 'public, max-age=60'  # 1 minute
    return response

@app.route('/api/online')
@rate_limit
def get_online_users():
    """Get current online users"""
    response = jsonify({
        'online': random.randint(200, 400),
        'peak_today': random.randint(500, 800)
    })
    response.headers['Cache-Control'] = 'no-cache'  # Always fresh
    return response

@app.route('/api/pricing')
@rate_limit
def get_pricing():
    """Get pricing info"""
    response = jsonify({
        'price': CRYMSON_PRICE,
        'type': 'one-time',
        'checkout_url': STRIPE_CHECKOUT_URL
    })
    response.headers['Cache-Control'] = 'public, max-age=3600'  # 1 hour
    return response

@app.route('/api/features')
@rate_limit
def get_features():
    """Get features"""
    response = jsonify({
        'features': [
            {'icon': '♾️', 'title': 'Infinite Games', 'description': 'Unlimited access'},
            {'icon': '🆓', 'title': 'All Games Free', 'description': 'Every game included'},
            {'icon': '💰', 'title': 'One-Time Payment', 'description': '$13 forever'},
            {'icon': '☁️', 'title': 'Cloud Saves', 'description': 'Sync everywhere'},
            {'icon': '⚡', 'title': 'Fast Servers', 'description': 'Priority access'}
        ]
    })
    response.headers['Cache-Control'] = 'public, max-age=3600'
    return response

@app.route('/api/faq')
@rate_limit
def get_faq():
    """Get FAQ"""
    response = jsonify({
        'faqs': [
            {'question': 'Is Crymson free?', 'answer': 'No, it\'s a one-time $13 purchase for lifetime access.'},
            {'question': 'What do I get?', 'answer': 'All games free, cloud saves, priority servers, forever.'},
            {'question': 'Is this a subscription?', 'answer': 'No! Pay $13 once, never again.'},
            {'question': 'Are games really free?', 'answer': 'Yes, every game is free with Crymson.'},
            {'question': 'How do I pay?', 'answer': 'Secure Stripe checkout, cards accepted.'}
        ]
    })
    response.headers['Cache-Control'] = 'public, max-age=3600'
    return response

@app.route('/api/purchases')
@rate_limit
def get_purchases():
    """Get all purchases"""
    purchases = load_purchases()
    response = jsonify({
        'total': len(purchases),
        'total_revenue': sum(p.get('amount', 0) for p in purchases),
        'purchases': purchases
    })
    response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
    return response

@app.route('/api/purchases/count')
@rate_limit
def get_purchase_count():
    """Get purchase count"""
    response = jsonify({'count': get_total_purchases()})
    response.headers['Cache-Control'] = 'no-cache'
    return response

# ========================================
# ERROR HANDLERS
# ========================================
@app.errorhandler(404)
def not_found(error):
    return app.send_static_file('index.html'), 404

@app.errorhandler(429)
def rate_limit_handler(error):
    return jsonify({'error': 'Too many requests. Please slow down.'}), 429

@app.errorhandler(500)
def server_error(error):
    print(f"Server error: {error}")
    return jsonify({'error': 'Internal server error'}), 500

@app.errorhandler(Exception)
def handle_exception(e):
    print(f"Unhandled exception: {e}")
    return jsonify({'error': 'An error occurred'}), 500

# ========================================
# MAIN
# ========================================
if __name__ == '__main__':
    print("\n" + "="*60)
    print("  🎮 Crymson Gaming Platform")
    print(f"  💰 Price: ${CRYMSON_PRICE} (One-Time)")
    print("  ⚡ Optimized & Secured")
    print("  Server: http://localhost:5000")
    print("="*60 + "\n")
    app.run(debug=True, host='0.0.0.0', port=5000, threaded=True)
